<?php
require_once dirname(__FILE__, 5) . '/wp-load.php'; // Load WordPress environment

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if contact form or simple contact form is submitted
    if (isset($_POST['action']) && $_POST['action'] === 'submit_contact_form') {
        // Process the contact form
        process_contact_form();
    } elseif (isset($_POST['action']) && $_POST['action'] === 'submit_simple_contact_form') {
        // Process the simple contact form
        process_simple_contact_form();
    } else {
        die('Neteisingas užklausos metodas.');
    }
}

function process_contact_form()
{
    // Sanitize and validate input fields
    $name = htmlspecialchars(trim($_POST['name']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $deliveryDate = htmlspecialchars(trim($_POST['delivery-date']));
    $deliveryTime = htmlspecialchars(trim($_POST['delivery-time']));
    $deliveryOption = htmlspecialchars(trim($_POST['delivery-option']));
    $deliveryAddress = htmlspecialchars(trim($_POST['delivery-address']));

    // Check required fields
    if (!$name || !$phone || !$email || !$deliveryDate || !$deliveryOption) {
        die('Prašome užpildyti visus privalomus laukus.');
    }

    // Prepare email content
    $to = 'your-email@example.com'; // Replace with your email address
    $subject = 'Galvosūkių dėžės rezervacija';
    $message = "Vardas: $name\n";
    $message .= "Telefono nr.: $phone\n";
    $message .= "El. paštas: $email\n";
    $message .= "Pristatymo diena: $deliveryDate\n";
    $message .= "Pristatymo laikas: $deliveryTime\n";
    $message .= "Pristatymo būdas: $deliveryOption\n";
    if ($deliveryOption === 'delivery') {
        $message .= "Pristatymo adresas: $deliveryAddress\n";
    }
    $headers = [
        'Content-Type: text/plain; charset=UTF-8',
        'From: ' . $name . ' <' . $email . '>',
    ];

    // Send email using wp_mail
    if (wp_mail($to, $subject, $message, $headers)) {
        // Redirect back with a success message
        wp_redirect(add_query_arg('form_submitted', 'true', wp_get_referer()));
        exit;
    } else {
        die('Nepavyko išsiųsti formos. Bandykite dar kartą.');
    }
}

function process_simple_contact_form()
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        $message = strip_tags($_POST['message']); // Remove HTML tags
        $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); // Convert special characters to HTML entities

        // Prepare the email content
        $email_subject = 'Nauja užklausa iš kontaktų formos';
        $email_message = "Gauta nauja užklausa:\n\n";
        $email_message .= "Vardas: $name\n";
        $email_message .= "El. paštas: $email\n";
        $email_message .= "Tel. numeris: $phone\n";
        $email_message .= "Žinutė:\n$message\n"; // Use $message here, not $message_content

        // Email recipient and headers
        $to = 'ol.gorbacevic@gmail.com'; // Replace with your email address
        $headers = [
            'Content-Type: text/plain; charset=UTF-8',
            'From: ' . $name . ' <' . $email . '>',
        ];

        // Send the email
        wp_mail($to, $email_subject, $email_message, $headers);

        // Redirect back with a success message
        wp_redirect(add_query_arg('form_submitted', 'true', wp_get_referer()));
        exit;
    }
}