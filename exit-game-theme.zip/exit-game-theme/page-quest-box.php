<?php
/**
 * Template Name: Quest Box Page
 *
 * A custom page template for displaying quest box details.
 *
 * @package Exit_Game_Theme
 */

get_header(); ?>

<?php get_template_part('template-parts/cover'); // Include the reusable cover section ?>

<div class="main-content">
    <div class="container">
        <!-- Custom Block Section -->
        <div class="custom-block">
            <!-- Players -->
            <div class="info-item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/people.png" alt="Players Icon">
                <p>2-6 žaidėjai</p>
            </div>

            <!-- Time -->
            <div class="info-item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/time.png" alt="Time Icon">
                <p>24 valandos</p>
            </div>

            <!-- Money -->
            <div class="info-item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/money.png" alt="Money Icon">
                <p>60 euro</p>
            </div>

            <!-- Difficulty -->
            <div class="info-item">
                <p>Sudėtingumas</p>
                <div class="difficulty-icons">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/star.png" alt="Star Icon">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/star.png" alt="Star Icon">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/star.png" alt="Star Icon">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/star.png" alt="Star Icon">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/star-none.png" alt="Star Icon">
                </div>
            </div>
        </div>

        <!-- General Content Section -->
        <div class="quest-content">
            <?php
            while ( have_posts() ) :
                the_post();
                the_content();
            endwhile;
            ?>
        </div>

        <?php render_about_block(); ?>
        <?php render_reviews_slider(); ?>
        
        <!-- Form Section -->
        <div class="contact-form-wrapper">
            <h2>Galvosūkių dėžės rezervacijos forma</h2>
            <?php get_template_part('template-parts/contact-form'); ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>