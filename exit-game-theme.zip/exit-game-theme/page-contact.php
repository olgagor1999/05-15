<?php
/**
 * Template Name: Contact Page
 * Description: A custom template for the contact page.
 */

get_header(); ?>

<?php get_template_part('template-parts/cover'); // Include the reusable cover section ?>

<section class="contact-page-wrapper">
    <div class="contact-page-container">
        <div class="contact-left">
            <p class="firm-name">Paslapties Kodas</p>
            <p class="contact-item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/phone-icon.png" alt="Phone Icon" class="contact-icon">
                <a href="tel:+1234567890">+370 6762 2085</a>
            </p>
            <p class="contact-item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/email.png" alt="Email Icon" class="contact-icon">
                <a href="mailto:info@example.com">info@galvosukiu-dezes.lt</a>
            </p>
            <p class="contact-item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/time.png" alt="Working Hours Icon" class="contact-icon">
                Pirm-Sekm: 8:00 AM - 20:00 PM
            </p>
            <div class="map-container">
                <iframe src="https://www.google.com/maps/embed?pb=YOUR_MAP_EMBED_CODE" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>

<div class="contact-right">
    <h2>Užklausos forma</h2>
    <p>Užpildykite formą ir mes su jumis susisieksime!</p>
    <?php get_template_part('template-parts/contact-form-simple'); // Include the new form ?>
</div>
</section>

<?php get_footer(); ?>
