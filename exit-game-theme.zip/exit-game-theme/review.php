// page-quest-box.php
<div class="reviews-section">
  <div class="reviews-container">
    <div class="reviews-slider">
      <?php
      $reviews = array(
        array(
          'text' => 'This is a great review!',
          'person_name' => 'John Doe',
          'person_image' => get_template_directory_uri() . '/assets/images/person1.jpg'
        ),
        array(
          'text' => 'I loved this product!',
          'person_name' => 'Jane Doe',
          'person_image' => get_template_directory_uri() . '/assets/images/person2.jpg'
        ),
        array(
          'text' => 'This is an amazing review!',
          'person_name' => 'Bob Smith',
          'person_image' => get_template_directory_uri() . '/assets/images/person3.jpg'
        ),
        array(
          'text' => 'I highly recommend this product!',
          'person_name' => 'Alice Johnson',
          'person_image' => get_template_directory_uri() . '/assets/images/person4.jpg'
        ),
        array(
          'text' => 'This is a fantastic review!',
          'person_name' => 'Mike Brown',
          'person_image' => get_template_directory_uri() . '/assets/images/person5.jpg'
        ),
        array(
          'text' => 'I love this product!',
          'person_name' => 'Emily Davis',
          'person_image' => get_template_directory_uri() . '/assets/images/person6.jpg'
        )
      );

      foreach ($reviews as $review) {
        ?>
        <div class="review-item">
          <div class="review-icon">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/stars-5.png" alt="5 stars">
          </div>
          <div class="review-text">
            <?php echo $review['text']; ?>
          </div>
          <div class="review-person">
            <img src="<?php echo $review['person_image']; ?>" alt="<?php echo $review['person_name']; ?>">
            <span><?php echo $review['person_name']; ?></span>
          </div>
        </div>
        <?php
      }
      ?>
    </div>
  </div>
</div>