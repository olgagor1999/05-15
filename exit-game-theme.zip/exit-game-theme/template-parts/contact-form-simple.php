    <form action="<?php echo esc_url(get_template_directory_uri() . '/inc/contact-form-process.php'); ?>" method="post" class="contact-form">
    <input type="hidden" name="action" value="submit_simple_contact_form">
    

    <!-- Name Field -->
    <label for="name">Jūsų vardas *</label>
    <input type="text" id="name" name="name" placeholder="Įveskite savo vardą" required>

    <!-- Email Field -->
    <label for="email">Jūsų el. paštas *</label>
    <input type="email" id="email" name="email" placeholder="Įveskite el. paštą" required>

    <!-- Phone Number Field -->
    <label for="phone">Jūsų tel. numeris</label>
    <input type="tel" id="phone" name="phone" placeholder="Įveskite tel. numerį">
    <small id="phone-error" style="display: none;">Įrašykite tik skaičius</small>

    <!-- Message Field -->
    <label for="message">Jūsų žinutė *</label>
    <textarea id="message" name="message" placeholder="Parašykite klausimą" required></textarea>

    <!-- Submit Button -->
    <button type="submit">Siųsti užklausą</button>
</form>
<!-- Success Message Modal -->
<?php if (isset($_GET['form_submitted']) && $_GET['form_submitted'] === 'true') : ?>
    <?php error_log('Success modal is being rendered.'); ?>
    <div id="success-modal" class="success-modal">
        <div class="success-modal-content">
            <p class="success-message">Dėkojame. Jūsų forma sėkmingai gauta. Netrukus su Jumis susisieksime!</p>
            <button id="close-modal" class="close-modal">Uždaryti</button>
        </div>
    </div>
<?php endif; ?>