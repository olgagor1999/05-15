<form action="<?php echo esc_url(get_template_directory_uri() . '/inc/contact-form-process.php'); ?>" method="post" class="contact-form">
    <input type="hidden" name="action" value="submit_contact_form">

    <!-- Name Field -->
    <label for="name">Vardas *</label>
    <input type="text" id="name" name="name" placeholder="Įveskite savo vardą" required>

    <!-- Phone Number Field -->
    <label for="phone">Telefono nr. *</label>
    <input type="tel" id="phone" name="phone" placeholder="Įveskite savo telefono numerį" required>
    <small id="phone-error" style="display: none;">Įrašykite tik skaičius</small>

    <!-- Email Field -->
    <label for="email">El. paštas *</label>
    <input type="email" id="email" name="email" placeholder="Įveskite savo el. paštą" required>

    <!-- Delivery Date Field -->
    <label for="delivery-date">Pasirinkite pristatymo dieną *</label>
    <input type="date" id="delivery-date" name="delivery-date" required min="<?php echo date('Y-m-d'); ?>">

    <!-- Delivery Time Field -->
    <label for="delivery-time">Pasirinkite pristatymo laiką *</label>
    <input type="time" id="delivery-time" name="delivery-time" required min="06:00" max="22:00">

    <!-- Delivery Option Field -->
    <label for="delivery-option">Pristatymas *</label>
    <select id="delivery-option" name="delivery-option" required>
        <option value="" disabled selected>Pasirinkite pristatymo būdą</option>
        <option value="delivery">Pristatymas į jūsų pasirinktą vietą</option>
        <option value="pickup">Atsimsiu pats Vilniuje</option>
    </select>
    <input id="delivery-address-container" type="text" name="delivery-address" placeholder="Įveskite adresą" style="display:none;">

    <!-- Agreement Fields -->
    <div class="agreement">
        <label>
            <input type="checkbox" name="privacy-policy" required>
            Sutinku su privatumo politika.
        </label>
        <label>
            <input type="checkbox" name="reservation-notice" required>
            Užklausos formos užpildymas negarantuoja galvosūkių dėžės rezervacijos.
        </label>
    </div>

    <!-- Submit Button -->
    <button type="submit">Siųsti užklausą</button>
</form>

<!-- Success Message Modal -->
<?php if (isset($_GET['form_submitted']) && $_GET['form_submitted'] === 'true') : ?>
    <?php error_log('Success modal is being rendered.'); ?>
    <div id="success-modal" class="success-modal">
        <div class="success-modal-content">
            <p class="success-message">Dėkojame. Jūsų forma sėkmingai gauta. Netrukus su Jumis susisieksime!</p>
            <button id="close-modal" class="close-modal">Uždaryti</button>
        </div>
    </div>
<?php endif; ?>