<?php


function register_posts_sidebar() {
    register_sidebar(array(
        'name' => 'Recent Posts',
        'id' => 'posts-sidebar',
        'description' => 'A sidebar block for recent posts from the blog.',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>'
    ));
}
add_action('widgets_init', 'register_posts_sidebar');


function enqueue_audio_page_styles() {
    if ( is_page_template( 'page-audio.php' ) ) {
        wp_enqueue_style( 'audio-page-style', get_template_directory_uri() . '/assets/css/audio-page.css' );
    }
}
add_action( 'wp_enqueue_scripts', 'enqueue_audio_page_styles' );

function enqueue_audio_player_scripts() {
    if ( is_page_template( 'page-audio.php' ) ) {
        wp_enqueue_script( 'audio-player-script', get_template_directory_uri() . '/assets/js/audio-player.js', array(), '1.0.0', true );
    }
}
add_action( 'wp_enqueue_scripts', 'enqueue_audio_player_scripts' );

function enqueue_font_awesome() {
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css' );
}
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );

// Register a new widget area for the header
function register_header_widget_area() {
    register_sidebar(array(
      'name' => 'Header Widget Area',
      'id' => 'header-widget-area',
      'description' => 'Widget area for the header',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget' => '</div>',
      'before_title' => '<h2 class="widget-title">',
      'after_title' => '</h2>',
    ));
  }
  add_action('widgets_init', 'register_header_widget_area');
  
// Enqueue styles for the quest box page
function enqueue_quest_box_styles() {
    if (is_page_template('page-quest-box.php')) {
        wp_enqueue_style('quest-box-page-style', get_template_directory_uri() . '/assets/css/quest-box-page.css');
    }
}
add_action('wp_enqueue_scripts', 'enqueue_quest_box_styles');


// filepath: [functions.php](http://_vscodecontentref_/4)

function enqueue_main_style () {
        wp_enqueue_style('exit-game-theme-main-style', get_template_directory_uri() . '/assets/css/style.css');
}
    
function enqueue_front_page_styles() {
    if (is_front_page()) {
        wp_enqueue_style('front-page-styles', get_template_directory_uri() . '/assets/css/front-page.css', array(), '1.0', 'all');
    }
}

function enqueue_single_post_css() {
    if ( is_single() ) {
        wp_enqueue_style( 'single-post', get_template_directory_uri() . '/assets/css/single-post.css', array(), '1.0.0', 'all' );
    }
}

// If template is Blog Template
function load_blog_template_styles() {
    if (is_page_template('blog.php')) { // Check if the page uses the Blog Template
        error_log('Blog template CSS is being enqueued.');
        wp_enqueue_style('blog-template-style', get_template_directory_uri() . '/assets/css/blog-template.css');
    }
    
}

function load_audio_template_styles() {
    if (is_page_template('page-audio.php')) {
        wp_enqueue_style('audio-template-style', get_template_directory_uri() . '/assets/css/audio-page.css');
    }
}

function load_quest_template_styles() {
    if (is_page_template('page-quest-box.php')) {
        wp_enqueue_style('quest-template-style', get_template_directory_uri() . '/assets/css/quest-box-page.css');
    }
}


add_action('wp_enqueue_scripts', 'enqueue_main_style');
add_action('wp_enqueue_scripts', 'enqueue_front_page_styles');
add_action('wp_enqueue_scripts', 'enqueue_single_post_css');
add_action('wp_enqueue_scripts', 'load_blog_template_styles'); // nekrauna
add_action('wp_enqueue_scripts', 'load_audio_template_styles'); 
add_action('wp_enqueue_scripts', 'load_quest_template_styles'); 



// Enqueue styles and scripts
function render_reviews_slider() {
  ?>
  <script>
    document.addEventListener('DOMContentLoaded', function(){
      // script.js
      * Renders a slider for customer reviews.
      *
      const reviewItems = document.querySelectorAll('.review-item');

      let currentSlide = 0;
      const slideWidth = reviewItems[0].offsetWidth;
      const slideCount = reviewItems.length;

      reviewsSlider.style.width = `${slideCount * slideWidth}px`;

      function nextSlide() {
        if (currentSlide < slideCount - 1) {
          currentSlide++;
          reviewsSlider.style.transform = `translateX(-${currentSlide * slideWidth}px)`;
        }
      }

      function prevSlide() {
        if (currentSlide > 0) {
          currentSlide--;
          reviewsSlider.style.transform = `translateX(-${currentSlide * slideWidth}px)`;
        }
      }

      // Add event listeners to navigation buttons
      document.querySelector('.next-btn').addEventListener('click', nextSlide);
      document.querySelector('.prev-btn').addEventListener('click', prevSlide);
    });
  </script>
  <?php
}


// Register widget areas
function exit_game_theme_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'exit-game-theme'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'exit-game-theme'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'exit_game_theme_widgets_init');



// Add a custom block for the about section
function render_about_block() {
    ?>
    <div class="container">
        <div class="about">
            <div class="about__body">
                <div class="about__header">
                    <div class="about__title title">Mūsų galvosūkių dėžė puikiai tinka</div>
                </div>
                <div class="about__row">
                    <div class="about__column">
                        <div class="item-about">
                            <div class="item-about__icon">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/galvosukiu-dezes-draugams.png" alt="galvosukių dėžės draugams">
                            </div>
                            <div class="item-about__title">Draugams ir šeimoms</div>
                            <div class="item-about__text">Patirkite jaudinančius nuotykius su šeima ir draugais!</div>
                        </div>
                    </div>
                    <div class="about__column">
                        <div class="item-about">
                            <div class="item-about__icon">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/galvosukiu-dezes-hobis.png" alt="galvosūkių dėžės hobis">
                            </div>
                            <div class="item-about__title">Pomėgiai detektyvai</div>
                            <div class="item-about__text">Jūs pats esate pomėgis detektyvas arba turite ypatingą idėją pasimatymui.</div>
                        </div>
                    </div>
                    <div class="about__column">
                        <div class="item-about">
                            <div class="item-about__icon">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/laisvalaikio-ideja.png" alt="laisvalaikio idėja">
                            </div>
                            <div class="item-about__title">Tendencijos kūrėjai</div>
                            <div class="item-about__text">Ar tau nuobodu ir ieškai naujų iššūkių?</div>
                        </div>
                    </div>
                    <div class="about__column">
                        <div class="item-about">
                            <div class="item-about__icon">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/bendruomeniskumas.png" alt="bendruomeniškumas">
                            </div>
                            <div class="item-about__title">Komandos formavimas</div>
                            <div class="item-about__text">Įmonės renginys, skirtas sukurti komandinę dvasią jūsų įmonėje.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Add custom image sizes
function exit_game_theme_image_sizes() {
    add_image_size('custom-size', 800, 600, true); // Example custom size
}
add_action('after_setup_theme', 'exit_game_theme_image_sizes');

// Include customizer and template functions
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/template-functions.php';

// Disable WordPress version in head for security
remove_action('wp_head', 'wp_generator');

// Add custom excerpt length
function exit_game_theme_excerpt_length($length) {
    return 20; // Set excerpt length to 20 words
}
add_filter('excerpt_length', 'exit_game_theme_excerpt_length');

// Add custom excerpt "read more" text
function exit_game_theme_excerpt_more($more) {
    return '... <a href="' . get_permalink() . '">' . __('Read More', 'exit-game-theme') . '</a>';
}
add_filter('excerpt_more', 'exit_game_theme_excerpt_more');
?>